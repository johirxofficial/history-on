const searchInput = document.getElementById('search');
const resultsDiv = document.getElementById('results');
const clearBtn = document.getElementById('clear-btn');

const formatTime = (timestamp) => {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + 
         date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
};

const getFavicon = (url) => {
  try { 
    const hostname = new URL(url).hostname;
    return `https://www.google.com/s2/favicons?sz=32&domain=${hostname}`;
  } catch { 
    return ''; 
  }
};

const render = (query = '') => {
  chrome.history.search({ text: query, maxResults: 100, startTime: 0 }, (data) => {
    if (data.length === 0) {
      resultsDiv.innerHTML = '<div style="text-align:center; color:#94a3b8; margin-top: 20px; font-size: 13px;">No history found.</div>';
      return;
    }
    resultsDiv.innerHTML = data.map(page => `
      <div class="item" onclick="window.open('${page.url}', '_blank')">
        <img class="favicon" src="${getFavicon(page.url)}" alt="" onerror="this.style.opacity='0'">
        <div class="info">
          <span class="title">${page.title || 'Unknown Title'}</span>
          <span class="url">${page.url}</span>
        </div>
        <span class="time">${formatTime(page.lastVisitTime)}</span>
      </div>
    `).join('');
  });
};

clearBtn.addEventListener('click', () => {
  if(confirm('WARNING: Are you sure you want to completely erase your browsing history? This cannot be undone.')) {
    chrome.history.deleteAll(() => {
      searchInput.value = '';
      render();
    });
  }
});

searchInput.addEventListener('input', e => render(e.target.value));
render();
