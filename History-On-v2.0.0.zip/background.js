// background.js — Service Worker (MV3)
chrome.runtime.onInstalled.addListener(() => {
  console.log('✅ History-On v2.0 installed');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStats') {
    chrome.history.search({text: '', maxResults: 1, startTime: 0}, (items) => {
      chrome.history.getVisits({url: items[0]?.url}, (visits) => {
        sendResponse({total: visits?.length || 0});
      });
    });
    return true; // async
  }
});
