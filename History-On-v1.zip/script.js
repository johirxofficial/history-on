const searchInput = document.getElementById('search');
const resultsDiv = document.getElementById('results');

const updateResults = (query = '') => {
  chrome.history.search({ text: query, maxResults: 40, startTime: 0 }, (results) => {
    resultsDiv.innerHTML = '';
    results.forEach(page => {
      const div = document.createElement('div');
      div.className = 'item';
      div.innerHTML = `<span class="title">${page.title || 'Unknown Page'}</span>
                     <span class="url">${page.url.substring(0, 50)}...</span>`;
      div.onclick = () => window.open(page.url, '_blank');
      resultsDiv.appendChild(div);
    });
  });
};

searchInput.addEventListener('input', () => updateResults(searchInput.value));
updateResults(); // Initial load
