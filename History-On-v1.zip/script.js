const searchInput = document.getElementById('search');
const resultsDiv = document.getElementById('results');

const render = (query = '') => {
  chrome.history.search({ text: query, maxResults: 50, startTime: 0 }, (data) => {
    resultsDiv.innerHTML = data.map(page => `
      <div class="item" onclick="window.open('${page.url}', '_blank')">
        <span class="title">${page.title || 'Untitled'}</span>
        <span class="url">${page.url}</span>
      </div>
    `).join('');
  });
};

searchInput.addEventListener('input', e => render(e.target.value));
render();
